function  printImpro(arquivo, dados)
%PRINTIMPRO Summary of this function goes here
%   Detailed explanation goes here

% funçao para realizar a impressão no arquivo que verifica melhoras. 

cd ..;
cd GRASP;
impressao(aquivo, dados);

end

