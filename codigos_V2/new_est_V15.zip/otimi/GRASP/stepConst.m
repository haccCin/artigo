function [ output_args ] = stepConst( input_args )
%STEPCONST Summary of this function goes here
%   Detailed explanation goes here


end

