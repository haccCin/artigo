function [ segDeri ] = deriSegund( primeDeri )
%DERISEGUND Summary of this function goes here
%   Detailed explanation goes here

tamPriDeri = size(primeDeri);
segDeri = zeros(tamPriDeri(1,1) - 1, tamPriDeri(1,2));
for i = 1 : tamPriDeri(1,2)
    for j = 1 : tamPriDeri(1,1) - 1
        
    end
end
end

